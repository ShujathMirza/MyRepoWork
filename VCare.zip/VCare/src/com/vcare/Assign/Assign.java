package com.vcare.Assign;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.vcare.AssignDB.AssignDB;
import com.vcare.Login.LoginDB.LoginDB;
import com.vcare.Login.LoginDB.User;
import com.vcare.util.EmailUtil;

/**
 * Servlet implementation class Assign which will help to assign resource for theparticular request
 */
@WebServlet("/Assign")
public class Assign extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Assign() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		String resourcename=request.getParameter("resource");
		String time=request.getParameter("hours");
		String reqId=request.getParameter("reqid");
		String service=request.getParameter("service");
		String status=request.getParameter("status");
		AssignDB db=new AssignDB();
		String value="";
		if(status!=null & status.equalsIgnoreCase("pending")){
			value="pending";
		}
		if(status!=null & status.equalsIgnoreCase("Approved")){
			value="Approved";

		}
		if(status!=null & status.equalsIgnoreCase("Deleted")){
			value="Deleted";

		}
		if(status!=null & status.equalsIgnoreCase("Complted")){
			value="Completed";

		}

		boolean isassigned=db.assignResource(resourcename,status,reqId);
		if(isassigned){
			
			LoginDB ldb=new LoginDB();
			User resource=ldb.getUserDetailsByName(resourcename);
			User user=ldb.getUserDetailsById(reqId);
			EmailUtil.AssignAssociate(resource.getEmail(), reqId, service, time);
			EmailUtil.ServerRequestDetails(user.getEmail(), reqId, service, time);
		
			
		}
		response.sendRedirect("Requests?operation="+value);
	}

}
