package com.vcare.Login;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.vcare.Login.LoginDB.LoginDB;
import com.vcare.Login.LoginDB.User;
import com.vcare.util.EmailUtil;
@WebServlet("/login")
public class LoginController extends HttpServlet{

	
	public void service(HttpServletRequest request,HttpServletResponse response){
		
		String userName=request.getParameter("uname");
		String password=request.getParameter("pwd");
		
		LoginDB db=new LoginDB();
		boolean status=db.login(userName, password);
		
		try {
			if(status){
				
				User user=db.getUserDetails(userName);
				HttpSession session=request.getSession();
				session.putValue("user", user);
				session.putValue("isLoggedIn", "true");
				System.out.println("role----------"+user.getRole());
				if(user.getRole().equalsIgnoreCase("User")){
					response.sendRedirect("Home.jsp");
				}
				else{
					response.sendRedirect("HomeAdmin.jsp");
				}
			
			}
			else{
				request.setAttribute("msg", "Invalid User Name or Password");
			RequestDispatcher dispatcher=request.getRequestDispatcher("AdminLogin.jsp");
			try {
				dispatcher.forward(request, response);
			} catch (ServletException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
