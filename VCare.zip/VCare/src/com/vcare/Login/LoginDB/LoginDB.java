package com.vcare.Login.LoginDB;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.vcare.util.DBconnection;

public class LoginDB {
	//check user exists or not if exists return true and login him
	public boolean login(String userName,String password){
		
		boolean isusrExists=false;

		Connection con=DBconnection.getConnection();
		
		try {
			Statement stmt=con.createStatement();
			String sql="select * from registration where username='"+userName+"' and password='"+password+"'";
			
			ResultSet rs=stmt.executeQuery(sql);
			while(rs.next()){
				isusrExists=true;
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return isusrExists;
		
	}
	
	//Get the user Details based on username
	public User getUserDetails(String userName){
		
	User userdetails=new User();

		Connection con=DBconnection.getConnection();
		
		try {
			Statement stmt=con.createStatement();
			String sql="select * from registration where username='"+userName+"'";
			
			ResultSet rs=stmt.executeQuery(sql);
			while(rs.next()){
				userdetails.setUserId(rs.getString("userid"));
				userdetails.setUserName(rs.getString("username"));
				userdetails.setEmail(rs.getString("email"));
				System.out.println("rolesssss"+rs.getString("role"));
				if(rs.getString("role")!=null && rs.getString("role").equalsIgnoreCase("user")){
					userdetails.setRole("User");	
				}
				else{
					userdetails.setRole("Admin");
				}
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return userdetails;
		
	}

	//Get the user Details based on userid

	public User getUserDetailsById(String reqid){
		
	User userdetails=new User();

		Connection con=DBconnection.getConnection();
		int userid=getUserIdByRequestId(reqid);
		try {
			Statement stmt=con.createStatement();
			String sql="select r.userid,r.username,h.resource,r.email,r.address,h.help from registration r, helprequests h where r.userid=h.userid and h.requestId='"+reqid+"' and r.userid='"+userid+"'";
			System.out.println("sql-----------"+sql);
			ResultSet rs=stmt.executeQuery(sql);
			while(rs.next()){
				userdetails.setUserId(rs.getString("userid"));
				userdetails.setUserName(rs.getString("username"));
				userdetails.setEmail(rs.getString("email"));
				userdetails.setAddress(rs.getString("address"));
				userdetails.setHelp(rs.getString("help"));
				userdetails.setResource(rs.getString("resource"));
			}
			userdetails.setReqId(reqid);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return userdetails;
		
	}
	//Get the user id based on requestid

	public int getUserIdByRequestId(String requestid) {
		Connection con = DBconnection.getConnection();
		int userid = 0;
		try {
			Statement stmt = con.createStatement();
			String sql = "select userid from helprequests where requestid='"+requestid +"'";
			System.out.println(sql);
			ResultSet rs = stmt.executeQuery(sql);
			while (rs.next()) {
				userid = rs.getInt(1);

			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return userid;
	}
	
	//Get the associates names created from database

	public ArrayList<User> getHelpers(){
			Connection con=DBconnection.getConnection();
			ArrayList<User> users=new ArrayList<User>();
			try {
				Statement stmt=con.createStatement();
				String sql="select * from registration where role='Helper'";
				
				ResultSet rs=stmt.executeQuery(sql);
				while(rs.next()){
					User userdetails=new User();
					userdetails.setUserId(rs.getString("userid"));
					userdetails.setUserName(rs.getString("username"));
					userdetails.setEmail(rs.getString("email"));
					System.out.println("rolesssss"+rs.getString("role"));
					users.add(userdetails);
					
				}
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			return users;
			
		}
	
	//Get the user Details based on username
	public User getUserDetailsByName(String userName){
		
		User userdetails=new User();

			Connection con=DBconnection.getConnection();
			
			try {
				Statement stmt=con.createStatement();
				String sql="select * from registration where username='"+userName+"'";
				
				ResultSet rs=stmt.executeQuery(sql);
				while(rs.next()){
					userdetails.setUserId(rs.getString("userid"));
					userdetails.setUserName(rs.getString("username"));
					userdetails.setEmail(rs.getString("email"));
					System.out.println("rolesssss"+rs.getString("role"));
					if(rs.getString("role")!=null && rs.getString("role").equalsIgnoreCase("user")){
						userdetails.setRole("User");	
					}
					else{
						userdetails.setRole("Admin");
					}
					
				}
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			return userdetails;
			
		}
}
