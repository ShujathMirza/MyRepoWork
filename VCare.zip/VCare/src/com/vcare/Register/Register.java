package com.vcare.Register;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.vcare.RegisterDB.RegisterDB;
import com.vcare.util.EmailUtil;
@WebServlet("/reg")
//New user can register here then an email is triggered and the values are stored in database
public class Register extends HttpServlet{
	
	public void service(HttpServletRequest request,HttpServletResponse response){
		String userName=request.getParameter("name");
		String password=request.getParameter("pwd");
		String rpassword=request.getParameter("rpwd");
		String email=request.getParameter("email");
		String address=request.getParameter("address");
		String city=request.getParameter("city");
		String state=request.getParameter("state");
		String zip=request.getParameter("zip");
		String gender=request.getParameter("gender");
		RegisterDB db=new RegisterDB();
		boolean status=db.insert(userName, password, rpassword, email, address, city, zip, state,gender);
		if(status){
			request.setAttribute("msg", "Registered Sucessfully.Please Login");
			EmailUtil.SendRegisteredEmail(email, userName,password);
		RequestDispatcher dispatcher=request.getRequestDispatcher("Register.jsp");
		try {
			dispatcher.forward(request, response);
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
	}

}
