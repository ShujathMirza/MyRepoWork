package com.vcare.AssignDB;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.vcare.util.DBconnection;

public class AssignDB {

	/*Take resource nmae,Status and Request Id and Assign a resource*/
	public boolean assignResource(String resourcename,String status,String requestID){
		
			Connection con = DBconnection.getConnection();
			try {
				String sql = "update helprequests set status=?,resource=? where requestid=?";
				PreparedStatement pstmt = con.prepareStatement(sql);
				pstmt.setString(1, status);
				pstmt.setString(2, resourcename);
				pstmt.setString(3, requestID);
				pstmt.executeUpdate();

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		return true;
	}
}
