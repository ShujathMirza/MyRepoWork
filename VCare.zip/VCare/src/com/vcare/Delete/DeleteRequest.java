package com.vcare.Delete;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.vcare.Login.LoginDB.User;
import com.vcare.RegisterDB.RegisterDB;
import com.vcare.RequestDB.Request;
import com.vcare.RequestDB.RequestDB;
import com.vcare.util.EmailUtil;

/**
 * Servlet implementation class DeleteRequest
 * 
 * The service method will Delete particular request if the request is not valid and the resource is not available
 */
@WebServlet("/DeleteRequest")
public class DeleteRequest extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DeleteRequest() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String requestid=request.getParameter("requestid");
		String role=request.getParameter("role");
		RequestDB db=new RequestDB();
		boolean isstatus=db.deleteRequest(requestid);
		if(isstatus){
			request.setAttribute("msg", "Request Deleted  Sucessfully");
			Request req=db.getUserRequest(requestid);
			EmailUtil.DeleteUserRequest(req.getEmail(),req.requesetId,req.getService());
			if(role.equalsIgnoreCase("admin")){
				request.setAttribute("operation", "delete");
				System.out.println("if -------------------------");
				response.sendRedirect("Requests");
				}
			else{
				System.out.println("else -------------------------");
				HttpSession session=request.getSession();
				User user=(User)session.getAttribute("user");
				ArrayList<Request> requests=db.getMyRequests(user.getUserId());
				session.putValue("myrequests", requests);
				RequestDispatcher dispatcher=request.getRequestDispatcher("MyRequests.jsp");
				dispatcher.forward(request, response);
			}
		}
		
		
		
	}

}
