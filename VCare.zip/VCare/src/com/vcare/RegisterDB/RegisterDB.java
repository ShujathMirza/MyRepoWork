package com.vcare.RegisterDB;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.vcare.util.DBconnection;

public class RegisterDB {

	//when new user try to register then the values has to be inserted into database
	public boolean insert(String username,String password,String rpassword,String email,String address,String city,String zip,String state,String gender){
	Connection con=DBconnection.getConnection();
		boolean isinserted=false;
		try {
		String sql="insert into registration(username,password,rpassword,email,address,city,state,ip,userid,role,gender) values(?,?,?,?,?,?,?,?,?,?,?)";
			
			PreparedStatement pstmt=con.prepareStatement(sql);
			
			pstmt.setString(1, username);
			pstmt.setString(2, password);
			pstmt.setString(3, rpassword);
			pstmt.setString(4, email);
			pstmt.setString(5, address);
			pstmt.setString(6,city);
			pstmt.setString(7, state);
			pstmt.setString(8, zip);
			pstmt.setInt(9, getUserId());
			pstmt.setString(10, "user");
			pstmt.setString(11, gender);
			pstmt.executeUpdate();
		
			isinserted=true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return isinserted;
	}
	
	
	
	public int getUserId() {

		int requestID = 0;
		Connection con = DBconnection.getConnection();

		try {
			Statement stmt = con.createStatement();
			String sql = "select max(userid) from registration";

			ResultSet rs = stmt.executeQuery(sql);
			while (rs.next()) {
				requestID = rs.getInt(1);
				requestID=requestID+1;
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return requestID;

	}
	
	
	public boolean insertHelper(String username,String password,String rpassword,String email,String address,String city,String zip,String state,String gender){
	Connection con=DBconnection.getConnection();
		boolean isinserted=false;
		try {
		String sql="insert into registration(username,password,rpassword,email,address,city,state,ip,userid,role,gender) values(?,?,?,?,?,?,?,?,?,?,?)";
			
			PreparedStatement pstmt=con.prepareStatement(sql);
			
			pstmt.setString(1, username);
			pstmt.setString(2, password);
			pstmt.setString(3, rpassword);
			pstmt.setString(4, email);
			pstmt.setString(5, address);
			pstmt.setString(6,city);
			pstmt.setString(7, state);
			pstmt.setString(8, zip);
			pstmt.setInt(9, getUserId());
			pstmt.setString(10, "Helper");
			pstmt.setString(11, gender);
			
			pstmt.executeUpdate();
		
			isinserted=true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return isinserted;
	}
}
