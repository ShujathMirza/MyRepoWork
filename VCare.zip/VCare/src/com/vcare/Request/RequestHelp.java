package com.vcare.Request;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.vcare.Login.LoginDB.User;
import com.vcare.RequestDB.RequestDB;
//this servlet will take all the values entered by client during taking help
/**
 * Servlet implementation class RequestHelp
 */
@WebServlet("/RequestHelp")
public class RequestHelp extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RequestHelp() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		String name=request.getParameter("name");
		String email=request.getParameter("email");
		String address=request.getParameter("address");
		String help=request.getParameter("help");
		String date=request.getParameter("date");
		String city=request.getParameter("city");
		String state=request.getParameter("state");
		String zip=request.getParameter("zip");

		HttpSession session=request.getSession();
		User user=(User)session.getAttribute("user");
		RequestDB req=new RequestDB();
		boolean status=req.insert(name, email, address, help, date, "",user.getUserId(),city,state,zip);
		if(status){
			request.setAttribute("inserted", "true");
			request.setAttribute("msg", "Requested Sucessfully");
			RequestDispatcher dispatcher=request.getRequestDispatcher("MyRequests");
			dispatcher.forward(request, response);
		}
		else{
			response.sendRedirect("Home.jsp");
		}
	}

}
