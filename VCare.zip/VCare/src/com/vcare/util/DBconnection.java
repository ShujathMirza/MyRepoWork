package com.vcare.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBconnection {
	//Get the connection from Database
	public static Connection getConnection(){
		//Register Drivver
		java.sql.Connection connection=null;
		try {
			try {
				Class.forName("com.mysql.jdbc.Driver");
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			//establish connection
			connection = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/one", "root", "root");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return connection;
	}

}
