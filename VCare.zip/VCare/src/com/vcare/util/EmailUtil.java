package com.vcare.util;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.NoSuchProviderException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.apache.commons.lang.RandomStringUtils;

public class EmailUtil {
	static Properties mailServerProperties;
	static Session MailSession;
	static MimeMessage MailMessage;
	
	public static String CreateVerification(){
		String verificationId=RandomStringUtils.random(14, true, true);
	return verificationId;
	}
	
	public static void SendRegisteredEmail(String emailId,String username,String password){
		
		mailServerProperties = System.getProperties();
		mailServerProperties.put("mail.smtp.port", "587");
		mailServerProperties.put("mail.smtp.auth", "true");
		mailServerProperties.put("mail.smtp.starttls.enable", "true");
		MailSession = Session.getDefaultInstance(mailServerProperties, null);
		MailMessage = new MimeMessage(MailSession);
		try {
			MailMessage.addRecipient(Message.RecipientType.TO, new InternetAddress(emailId));
			MailMessage.addRecipient(Message.RecipientType.CC, new InternetAddress("caringforelderlypeople@gmail.com"));
			MailMessage.setSubject("Greetings from Caring for Elderley");
			String emailBody = "Hi <br> Welocme to the Caring for Elderley <br> Your User Name  " +username+ "<br> Password is <br>"+password+"<br> Regards, <br>Caring Elderley Admin";
			MailMessage.setContent(emailBody, "text/html");
		} catch (MessagingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	
		Transport transport;
		try {
			transport = MailSession.getTransport("smtp");
			try {
				transport.connect("smtp.gmail.com", "caringforelderlypeople@gmail.com", "sacredheart");
				transport.sendMessage(MailMessage, MailMessage.getAllRecipients());
				transport.close();
			} catch (MessagingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		} catch (NoSuchProviderException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}
	
	
public static void DeleteUserRequest(String emailId,String requestid,String service){
		
		mailServerProperties = System.getProperties();
		mailServerProperties.put("mail.smtp.port", "587");
		mailServerProperties.put("mail.smtp.auth", "true");
		mailServerProperties.put("mail.smtp.starttls.enable", "true");
		MailSession = Session.getDefaultInstance(mailServerProperties, null);
		MailMessage = new MimeMessage(MailSession);
		try {
			MailMessage.addRecipient(Message.RecipientType.TO, new InternetAddress(emailId));
			MailMessage.addRecipient(Message.RecipientType.CC, new InternetAddress("caringforelderlypeople@gmail.com"));
			MailMessage.setSubject("Your request Cannot be proceesed at this time");
			String emailBody = "Hi <br> Welocme to the caring for Elderly <br><br> We cannot serve request in Current location or we dont provide the service requested that is <b>"+service+"</b><br><br> Regards, <br>Caring For Elderley Admin";
			MailMessage.setContent(emailBody, "text/html");
		} catch (MessagingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	
		Transport transport;
		try {
			transport = MailSession.getTransport("smtp");
			try {
				transport.connect("smtp.gmail.com", "caringforelderlypeople@gmail.com", "sacredheart");
				transport.sendMessage(MailMessage, MailMessage.getAllRecipients());
				transport.close();
			} catch (MessagingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		} catch (NoSuchProviderException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}


	public static void AssignAssociate(String emailId, String requestid,
			String service, String time) {

		mailServerProperties = System.getProperties();
		mailServerProperties.put("mail.smtp.port", "587");
		mailServerProperties.put("mail.smtp.auth", "true");
		mailServerProperties.put("mail.smtp.starttls.enable", "true");
		MailSession = Session.getDefaultInstance(mailServerProperties, null);
		MailMessage = new MimeMessage(MailSession);
		try {
			MailMessage.addRecipient(Message.RecipientType.TO,
					new InternetAddress(emailId));
			MailMessage.addRecipient(Message.RecipientType.CC,
					new InternetAddress("caringforelderlypeople@gmail.com"));
			MailMessage
					.setSubject("Your request is  Approved and Resource is Assigned");
			String emailBody = "Hi <br> Welocme to the caring for Elderly <br><br> Our Resource will be with you shortley in the given time "+time+"   <b> For the service "
					+ service
					+ "</b><br><br> Regards, <br>Caring For Elderley Admin";
			MailMessage.setContent(emailBody, "text/html");
		} catch (MessagingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Transport transport;
		try {
			transport = MailSession.getTransport("smtp");
			try {
				transport.connect("smtp.gmail.com",
						"caringforelderlypeople@gmail.com", "sacredheart");
				transport.sendMessage(MailMessage,
						MailMessage.getAllRecipients());
				transport.close();
			} catch (MessagingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		} catch (NoSuchProviderException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	

	public static void ServerRequestDetails(String emailId, String requestid,
			String service, String time) {

		mailServerProperties = System.getProperties();
		mailServerProperties.put("mail.smtp.port", "587");
		mailServerProperties.put("mail.smtp.auth", "true");
		mailServerProperties.put("mail.smtp.starttls.enable", "true");
		MailSession = Session.getDefaultInstance(mailServerProperties, null);
		MailMessage = new MimeMessage(MailSession);
		try {
			MailMessage.addRecipient(Message.RecipientType.TO,
					new InternetAddress(emailId));
			MailMessage.addRecipient(Message.RecipientType.CC,
					new InternetAddress("caringforelderlypeople@gmail.com"));
			MailMessage
					.setSubject("Given Detail to work");
			String emailBody = "Hi <br> Welocme to the caring for Elderly <br><br> Our User is Seeking help at given time "+time+"<b> For the Service "
					+ service
					+ "</b><br><br> Regards, <br>Caring For Elderley Admin";
			MailMessage.setContent(emailBody, "text/html");
		} catch (MessagingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Transport transport;
		try {
			transport = MailSession.getTransport("smtp");
			try {
				transport.connect("smtp.gmail.com",
						"caringforelderlypeople@gmail.com", "sacredheart");
				transport.sendMessage(MailMessage,
						MailMessage.getAllRecipients());
				transport.close();
			} catch (MessagingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		} catch (NoSuchProviderException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
public static boolean  contactUs(String emailId,String phonenumber,String message,String name){
		
		mailServerProperties = System.getProperties();
		mailServerProperties.put("mail.smtp.port", "587");
		mailServerProperties.put("mail.smtp.auth", "true");
		mailServerProperties.put("mail.smtp.starttls.enable", "true");
		MailSession = Session.getDefaultInstance(mailServerProperties, null);
		MailMessage = new MimeMessage(MailSession);
		try {
			MailMessage.addRecipient(Message.RecipientType.TO, new InternetAddress("caringforelderlypeople@gmail.com"));
			MailMessage.addRecipient(Message.RecipientType.CC, new InternetAddress("caringforelderlypeople@gmail.com"));
			MailMessage.setSubject("Contact Message");
			String emailBody = "Hi <br> Resource Name  "+name+"<br><br> Is contacting you regarding"+message+"and contact Details and Email is as follows"+emailId+ " "+phonenumber +"</b><br><br> Regards, <br>Caring For Elderley Admin";
			MailMessage.setContent(emailBody, "text/html");
		} catch (MessagingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	
		Transport transport;
		try {
			transport = MailSession.getTransport("smtp");
			try {
				transport.connect("smtp.gmail.com", "caringforelderlypeople@gmail.com", "sacredheart");
				transport.sendMessage(MailMessage, MailMessage.getAllRecipients());
				transport.close();
			} catch (MessagingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		} catch (NoSuchProviderException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
return true;
	}

}
