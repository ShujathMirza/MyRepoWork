package com.vcare.Associate;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.vcare.RegisterDB.RegisterDB;
import com.vcare.util.EmailUtil;

/**
 * Servlet implementation class CreateAssociate
 * 
 * Admin can create a new associate and can assign to particular request
 */
@WebServlet("/CreateAssociate")
public class CreateAssociate extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CreateAssociate() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		String userName=request.getParameter("name");
		String email=request.getParameter("email");
		String address=request.getParameter("address");
		String city=request.getParameter("city");
		String state=request.getParameter("state");
		String zip=request.getParameter("zip");
		String gender=request.getParameter("gender");
		RegisterDB db=new RegisterDB();
		boolean status=db.insertHelper(userName, "", "", email, address, city, zip, state,gender);
		if(status){
			request.setAttribute("msg", "Assocaite Created Sucessfully");
			EmailUtil.SendRegisteredEmail(email, userName,"");
		RequestDispatcher dispatcher=request.getRequestDispatcher("createAssociate.jsp");
		try {
			dispatcher.forward(request, response);
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
	}

}
