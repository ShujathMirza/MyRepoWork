package com.vcare.RequestDB;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.vcare.util.DBconnection;

public class RequestDB implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1928632731324131072L;

//when client seeeks new request values will be inserted in database
	public boolean insert(String name, String email, String address,
			String help, String todate, String fromdate, String userid,String city,String state,String zip) {
		Connection con = DBconnection.getConnection();
		boolean isrequested = false;
		try {
			String sql = "insert into helprequests(requestid,name,email,address,help,todate,fromdate,status,userid,city,state,zip) values(?,?,?,?,?,?,?,?,?,?,?,?)";

			PreparedStatement pstmt = con.prepareStatement(sql);

			pstmt.setInt(1, getRequestId());
			pstmt.setString(2, name);
			pstmt.setString(3, email);
			pstmt.setString(4, address);
			pstmt.setString(5, help);
			pstmt.setString(6, todate);
			pstmt.setString(7, fromdate);
			pstmt.setString(8, "pending");
			pstmt.setString(9, userid);
			pstmt.setString(10, city);
			pstmt.setString(11, state);
			pstmt.setString(12, zip);
			pstmt.executeUpdate();
			isrequested = true;

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return isrequested;
	}
//for each reequest requestid will be created
	public int getRequestId() {

		int requestID = 0;
		Connection con = DBconnection.getConnection();

		try {
			Statement stmt = con.createStatement();
			String sql = "select max(requestid) from helprequests";

			ResultSet rs = stmt.executeQuery(sql);
			while (rs.next()) {
				requestID = rs.getInt(1);
				requestID = requestID + 1;
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return requestID;

	}
//get the requests based on userid
	public ArrayList<Request> getMyRequests(String userid) {
		Connection con = DBconnection.getConnection();
		ArrayList<Request> myrequests = new ArrayList<Request>();
		try {
			Statement stmt = con.createStatement();
			String sql = "select * from helprequests where userid='" + userid
					+ "' and status<>'Delete'";

			System.out.println(sql);
			ResultSet rs = stmt.executeQuery(sql);
			while (rs.next()) {

				Request request = new Request();
				request.setRequesetId(rs.getString(1));
				request.setUsername(rs.getString(2));
				request.setEmail(rs.getString(3));
				request.setAddress(rs.getString(4));
				request.setService(rs.getString(5));
				request.setTodate(rs.getString(6));
				request.setFromdate(rs.getString(7));
				request.setStatus(rs.getString(8));
				request.setUserid(rs.getString(9));
				request.setCity(rs.getString(10));
				request.setState(rs.getString(11));
				request.setZip(rs.getString(12));
				myrequests.add(request);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return myrequests;
	}
	
	//Admin can get all the requests that he asked
	public ArrayList<Request> getAllRequests() {
		Connection con = DBconnection.getConnection();
		ArrayList<Request> myrequests = new ArrayList<Request>();
		try {
			Statement stmt = con.createStatement();
			String sql = "select * from helprequests where status='pending'";
			System.out.println(sql);
			ResultSet rs = stmt.executeQuery(sql);
			while (rs.next()) {

				Request request = new Request();
				request.setRequesetId(rs.getString(1));
				request.setUsername(rs.getString(2));
				request.setEmail(rs.getString(3));
				request.setAddress(rs.getString(4));
				request.setService(rs.getString(5));
				request.setTodate(rs.getString(6));
				request.setFromdate(rs.getString(7));
				request.setStatus(rs.getString(8));
				myrequests.add(request);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return myrequests;
	}
	
	
	public ArrayList<Request> getAllRequestsInclude() {
		Connection con = DBconnection.getConnection();
		ArrayList<Request> myrequests = new ArrayList<Request>();
		try {
			Statement stmt = con.createStatement();
			String sql = "select * from helprequests";
			System.out.println(sql);
			ResultSet rs = stmt.executeQuery(sql);
			while (rs.next()) {

				Request request = new Request();
				request.setRequesetId(rs.getString(1));
				request.setUsername(rs.getString(2));
				request.setEmail(rs.getString(3));
				request.setAddress(rs.getString(4));
				request.setService(rs.getString(5));
				request.setTodate(rs.getString(6));
				request.setFromdate(rs.getString(7));
				request.setStatus(rs.getString(8));
				myrequests.add(request);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return myrequests;
	}
	//when admin or client deletes the requesrt the status is marked as delete
	public boolean deleteRequest(String requestId){
		Connection con = DBconnection.getConnection();
		boolean isdeleted=false;
		try {
			String sql = "update helprequests set status=? where requestid=?";
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setString(1, "Delete");
			pstmt.setString(2, requestId);
			pstmt.executeUpdate();
			isdeleted=true;

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return isdeleted;
	}
	
	//getting user Deaails based on the requestid
	public Request getUserRequest(String reqid) {
		Connection con = DBconnection.getConnection();
		Request request = new Request();
		try {
			Statement stmt = con.createStatement();
			String sql = "select * from helprequests where requestId='" + reqid
					+ "'";
			System.out.println(sql);
			ResultSet rs = stmt.executeQuery(sql);
			while (rs.next()) {

				
				request.setRequesetId(rs.getString(1));
				request.setUsername(rs.getString(2));
				request.setEmail(rs.getString(3));
				request.setAddress(rs.getString(4));
				request.setService(rs.getString(5));
				request.setTodate(rs.getString(6));
				request.setFromdate(rs.getString(7));
				request.setStatus(rs.getString(8));
				request.setUserid(rs.getString(9));
				
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return request;
	}
}
